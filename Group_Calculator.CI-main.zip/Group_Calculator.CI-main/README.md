# Group_Calculator.CI

In this project we created a basic command line calculator in python, you are able to: add, subtract, multiply and divide two numbers to get the correct answer. we also added a loop into the mix to ask if you would like to continue with your calculations, this was done using a 'while' loop. we also allowed the program to raise some errors if non-defined operators were used and if you tried to input a 'string' instead of an 'integer' or 'float'.

# How to use the calculator?

As you might have guessed it's no different to any other calculator...run the program, enter your first number when prompted, choose your operator(+,-,*,/), then enter your second number and wait for your result!

# Link to the replit

https://replit.com/@DanSewell/Calculate
